# DFC2019_Semantic > 2024-09-12 2:26pm
https://universe.roboflow.com/rs-seev5/dfc2019_semantic

Provided by a Roboflow user
License: CC BY 4.0

